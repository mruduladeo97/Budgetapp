package com.cdac.cntr;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.type.DateType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Expense;
import com.cdac.dto.User;
import com.cdac.service.ExpenseService;

@Controller
public class ExpenseController {
	
	@Autowired
	private ExpenseService expenseService;
	
//	@RequestMapping(value = "/prep_expense_add_form.htm",method = RequestMethod.GET)
//	public String prepExpenseAddForm(ModelMap map,HttpSession session,HttpServletResponse response) throws IOException {
//		UserController.protectRoute(session,response );
//		map.put("expense", new Expense());
//		return "expense_add_form";
//	}
	
	
	@RequestMapping(value = "/return_dashboard.htm",method = RequestMethod.GET)
	public String returnDashboard(ModelMap map,HttpSession session,HttpServletResponse response) throws IOException {
		UserController.protectRoute(session,response );
		map.put("expense", new Expense());
		return "redirect:expense_list.htm";
	}
	
	@RequestMapping(value = "/expense_add.htm",method = RequestMethod.POST)
	public String expenseAdd( Expense expense,HttpSession session)  {
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;
		String userName = ((User)session.getAttribute("user")).getUserName();
		expense.setUserId(userId);
		expense.setUserName(userName);
//		expense.setPostingDate(new SimpleDateFormat("yyyy/MM/dd").parse(postingDate));
		
		
		expenseService.addExpense(expense);
		return "redirect:expense_list_1.htm";
	}
	
	
	@RequestMapping(value = "/expense_list.htm",method = RequestMethod.GET)
	public String allExpenses(ModelMap map,HttpSession session,HttpServletResponse response) throws IOException {
		
		UserController.protectRoute(session,response );
		
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;
		List<Expense> li = expenseService.selectAll(userId);
		
		List<Expense> li1 = expenseService.selectReport();
		
		map.put("reportExpList", li1);
		map.put("expList", li);
		return "dashboard";
	}
	
	@RequestMapping(value = "/expense_list_1.htm",method = RequestMethod.GET)
	public String allExpenses_1(ModelMap map,HttpSession session,HttpServletResponse response) throws IOException {
		
		UserController.protectRoute(session,response );
		
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;
		List<Expense> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "new_expense_list";
	}
	
	
	@RequestMapping(value = "/expense_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int expenseId,ModelMap map,HttpSession session) {
		
		expenseService.removeExpense(expenseId); 
		
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;
		List<Expense> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "redirect:expense_list.htm";
	}
	
	
	@RequestMapping(value = "/expense_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int expenseId,ModelMap map,HttpSession session,HttpServletResponse response) throws IOException {
		
		UserController.protectRoute(session,response );
		Expense exp = expenseService.findExpenxe(expenseId);
		map.put("expense", exp);
		
		return "exp_update_form";
	}
	
	@RequestMapping(value = "/expense_update.htm",method = RequestMethod.POST)
	public String expenseUpdate(Expense expense,ModelMap map,HttpSession session) {
		
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;
		expense.setUserId(userId);
		expenseService.modifyExpense(expense);
			
		List<Expense> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "redirect:expense_list.htm";
	}
	
//	@RequestMapping(value = "/expense_report_form.htm",method = RequestMethod.GET)
//	public String expensesReportForm(ModelMap map,HttpSession session) {
//		
//		return "expense_report_form";
//	}
	
	
	@RequestMapping(value = "/expense_report.htm",method = RequestMethod.GET)
	public String expensesReport(ModelMap map,HttpSession session,HttpServletResponse response) throws IOException  {
		UserController.protectRoute(session,response );
		int userId = (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute("user")).getUserId():0;

		List<Expense> li = expenseService.selectReport();
		for(Expense e:li) {
			System.out.println(e.getItemName());
			System.out.println(e.getPrice());
			
		}
		map.put("reportExpList", li);
		//return "expense_report";
		return "expense_report";
	}
	
	
}

package com.cdac.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.dto.Expense;
import com.cdac.dto.User;
import com.cdac.service.Email;
import com.cdac.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private Email email;

	@RequestMapping(value = "/go_to_home.htm", method = RequestMethod.GET)
	public String goToHome(ModelMap map) {

		return "index";
	}

	@RequestMapping(value = "/prep_reg_form.htm", method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new User());
		return "register";
	}

	@RequestMapping(value = "/reg.htm", method = RequestMethod.POST)
	public String register(User user, ModelMap map) {

		if (user.getUserMail() == null) {
			return "register";
		}

		else {

			String senderEmailId = "pranays297@gmail.com";
			String receiverEmailId = user.getUserMail();
			String subject = "Register Conformation";
			String message = "Welcome " + user.getUserName() + " to our website!!!" + " \nClick on below link for LOGIN"
					+ "\nhttp://localhost:8080/Daily-Budget-Tracker/prep_log_form.htm";

			email.sendEmail(senderEmailId, receiverEmailId, subject, message);

			System.out.println("Email sent successfully");
			userService.addUser(user);
			return "reg_success";
		}

		// return "login";
	}

	@RequestMapping(value = "/prep_log_form.htm", method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new User());
		return "login";
	}

	@RequestMapping(value = "/home.htm", method = RequestMethod.POST)
	public String login(User user, ModelMap map, HttpSession session, HttpServletResponse response) throws IOException {
		// UserController.protectRoute(session,response );
		boolean b = userService.findUser(user);
		if (b) {
			session.setAttribute("user", user);
			return "redirect:index_page.htm";
			// if(user.getUserMail().equals("pranays297@gmail.com") &&
			// user.getUserPassword().equals("1234"))
//			if(user.getUserId() == 7){
//				return "redirect:index_page.htm";
//			}
//			else {
//				return "redirect:index_page.htm";
//				//return "home";
//			}

		} else {
			String msa = "Wrong Credential!!!!!";
			map.put("msg",msa);
			//map.put("user", new User());
			return "login";

		}
	}

	@RequestMapping(value = "/index_page.htm", method = RequestMethod.GET)
	public String sendToHome(ModelMap map, HttpSession session, HttpServletResponse response) throws IOException {

		User user = (User) session.getAttribute("user");
		UserController.protectRoute(session, response);
		if (user.getUserId() == 7) {
			System.out.println("===========+++++++++++++++++++++++" + user);
			return "redirect:show_all_users.htm";
		} else {
			return "redirect:expense_list.htm";
		}

		// return "redirect:expense_report.htm";
	}

	@RequestMapping(value = "/user_update_form.htm", method = RequestMethod.GET)
	public String userUpdateForm(ModelMap map, HttpSession session, HttpServletResponse response) throws IOException {

		UserController.protectRoute(session, response);
		int userId = (((User) session.getAttribute("user")) != null) ? ((User) session.getAttribute("user")).getUserId()
				: 0;
		User user = userService.selectUser(userId);
		map.put("user", user);

		return "update_form";
	}

	@RequestMapping(value = "/user_update.htm", method = RequestMethod.POST)
	public String userUpdate(User user, ModelMap map, HttpSession session, HttpServletResponse response)
			throws IOException {

		UserController.protectRoute(session, response);
		int userId = (((User) session.getAttribute("user")) != null) ? ((User) session.getAttribute("user")).getUserId()
				: 0;
		String uPass = (((User) session.getAttribute("user")) != null)
				? ((User) session.getAttribute("user")).getUserPassword()
				: "";
		user.setUserId(userId);
		user.setUserPassword(uPass);
		userService.modifyProfile(user);
		System.out.println(user);
		
		if(userId == 7) {
			return "redirect:show_all_users.htm";
		}
		else {
			return "redirect:expense_list.htm";
		}
		
	}

	@RequestMapping(value = "/user_pass_update_form.htm", method = RequestMethod.GET)
	public String userPassUpdateForm(ModelMap map, HttpSession session, HttpServletResponse response)
			throws IOException {

		UserController.protectRoute(session, response);
		map.put("user", new User());

		return "user_pass_update";
	}

	@RequestMapping(value = "/user_pass_update.htm", method = RequestMethod.GET)
	public String userPassUpdate(@RequestParam("oldPass") String oldPass, @RequestParam("newPass") String newPass,
			@RequestParam("cPass") String cPass, User user, HttpSession session, HttpServletResponse response)
			throws IOException {
		UserController.protectRoute(session, response);
		int userId = (((User) session.getAttribute("user")) != null) ? ((User) session.getAttribute("user")).getUserId()
				: 0;
		user.setUserId(userId);

		user = userService.selectUser(userId);
		if (user.getUserPassword().equals(oldPass) && newPass.equals(cPass) && user.getUserId() == 7) {
			user.setUserPassword(newPass);
			userService.updatePassword(user);
			return "redirect:show_all_users.htm";
		} else if (user.getUserPassword().equals(oldPass) && newPass.equals(cPass)) {
			user.setUserPassword(newPass);
			userService.updatePassword(user);
			return "redirect:expense_list.htm";
		} else {
			return "user_pass_update";
		}

	}

	@RequestMapping(value = "/user_forget_pass_form.htm", method = RequestMethod.GET)
	public String userForgetPass(ModelMap map, HttpSession session) {

		map.put("user", new User());

		return "forget";
	}

	@RequestMapping(value = "/send_mail_forget.htm", method = RequestMethod.GET)
	public String sendMailForForgetPass(@RequestParam String eMail, ModelMap map, HttpSession session) {
		map.put("user", new User());
		// int userId = ((User)session.getAttribute("user")).getUserId();
		String userPass = userService.userForgetPass(eMail);

		if (userPass == null) {
			return "forget";
		}

		else {

			String senderEmailId = "pranays297@gmail.com";
			String receiverEmailId = eMail;
			String subject = "Get Your Password";
			String message = "Now Your Password is => " + userPass;

			email.sendEmail(senderEmailId, receiverEmailId, subject, message);

			System.out.println("Email sent successfully");
			System.out.println("=====================================ffff" + eMail);
			return "forget_success";
		}

	}

	@RequestMapping(value = "/user_logout.htm", method = RequestMethod.GET)
	public String userLogout(ModelMap map, HttpSession session) {

		session.invalidate();

		return "index";
	}

	// Admin
	@RequestMapping(value = "/show_all_users.htm", method = RequestMethod.GET)
	public String showAllUsers(ModelMap map, HttpSession session, HttpServletResponse response) throws IOException {

		
		  UserController.protectRoute(session,response ); int userId =
		  (((User)session.getAttribute("user"))!=null)?((User)session.getAttribute(
		  "user")).getUserId():0;
		  
		  List<User> li = userService.showAllUsers();
		  System.out.println("all user======"); map.put("allUserList", li);
		 
		return "admin";
	}

	@RequestMapping(value = "/user_delete.htm", method = RequestMethod.GET)
	public String userDelete(@RequestParam int userId, ModelMap map, HttpSession session) {
		System.out.println(userId + "======");
		userService.removeUser(userId);

		List<User> li = userService.showAllUsers();
		map.put("allUserList", li);
		return "redirect:show_all_users.htm";
	}

	static void protectRoute(HttpSession session, HttpServletResponse response) throws IOException {
		User user = (User) session.getAttribute("user");

		if (user == null) {
			response.sendRedirect("./");
		}
	}

}

package com.cdac.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="expense")
public class Expense {
	
	@Id
	@GeneratedValue
	@Column(name="expense_id")
	private int expenseId;
	@Column(name="posting_date")
//	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String postingDate;
	@Column(name="item_name")
	private String itemName;
	private float price;
	@Column(name="user_id")
	private int userId;
	private String userName;
	public Expense() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Expense(int expenseId) {
		super();
		this.expenseId = expenseId;
	}


	public Expense(int expenseId, String postingDate, String itemName, float price, int userId,String userName) {
		super();
		this.expenseId = expenseId;
		this.postingDate = postingDate;
		this.itemName = itemName;
		this.price = price;
		this.userId = userId;
		this.userName=userName;
	}
	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public int getExpenseId() {
		return expenseId;
	}
	public void setExpenseId(int expenseId) {
		this.expenseId = expenseId;
	}
	public String getPostingDate() {
		return postingDate;
	}
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "Expense [expenseId=" + expenseId + ", postingDate=" + postingDate + ", itemName=" + itemName + ", price="
				+ price + ", userId=" + userId + "]";
	}
	
	
}

package com.cdac.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.UserDao;
import com.cdac.dto.Expense;
import com.cdac.dto.User;

@Service
public class UserServiceImple implements UserService {
	
	@Autowired
	private UserDao userDao; 
		
	@Override
	public void addUser(User user) {
		
		userDao.insertUser(user);
		
	}

	@Override
	public boolean findUser(User user) {
		
		return userDao.checkUser(user);
	}
	
	@Override
	public User selectUser(int userId) {
		// TODO Auto-generated method stub
		return userDao.selectUser(userId);
	}


	@Override
	public void modifyProfile(User user) {
		
		userDao.updateProfile(user);
		
	}
	
	public void updatePassword(User user) {
		
		userDao.updatePassword(user);
	}

	@Override
	public List<User> showAllUsers() {
		
		return userDao.showAllUsers();
	}

	@Override
	public void removeUser(int userId) {

		userDao.removeUser(userId);
		
	}

	@Override
	public String userForgetPass(String eMail) {
		
		return userDao.userForgetPass(eMail);
	}

	@Override
	public void uploadImage(String fileName, int userId) {
		userDao.uploadImage(fileName,userId);
		
	}

	
	

	
	

}

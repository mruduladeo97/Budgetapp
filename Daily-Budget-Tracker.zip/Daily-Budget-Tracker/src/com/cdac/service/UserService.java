package com.cdac.service;

import java.util.Date;
import java.util.List;

import com.cdac.dto.Expense;
import com.cdac.dto.User;

public interface UserService {
	void addUser(User user);
	boolean findUser(User user);
	
	public User selectUser(int userId);
	public void modifyProfile(User user);
	
	public void updatePassword(User user);
	
	public List<User> showAllUsers();
	
	public void removeUser(int userId);
	
	public String userForgetPass(String eMail);
	void uploadImage(String fileName, int userId);
}

package com.cdac.dao;

import java.util.Date;
import java.util.List;

import com.cdac.dto.Expense;
import com.cdac.dto.User;

public interface ExpenseDao {
	
	void insertExpense(Expense expense);
	void deleteExpense(int expenseId);
	Expense selectExpenxe(int expenseId);
	void updateExpense(Expense expense);
	List<Expense> selectAll(int userId);
	
	public List<Expense> selectReport();
}

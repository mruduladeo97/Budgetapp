package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Expense;
import com.cdac.dto.User;

public interface UserDao {
	
	void insertUser(User user);
	boolean checkUser(User user);
	
	public User selectUser(int userId);
	public void updateProfile(User user);
	public void updatePassword(User user);
	public List<User> showAllUsers();
	public void removeUser(int userId);
	public String userForgetPass(String eMail);
	void uploadImage(String fileName, int userId);
	
}

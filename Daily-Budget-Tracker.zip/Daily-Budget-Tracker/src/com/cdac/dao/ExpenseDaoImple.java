package com.cdac.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Expense;
import com.cdac.dto.User;

@Repository
public class ExpenseDaoImple implements ExpenseDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertExpense(Expense expense) {
		
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(expense);
				tr.commit();
				session.flush();
				session.close();
				
				return null;
				
			}
		});
	}

	@Override
	public void deleteExpense(int expenseId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Expense expense = new Expense(expenseId);
				session.delete(expense);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
	}

	@Override
	public Expense selectExpenxe(int expenseId) {
		
		Expense expense= hibernateTemplate.execute(new HibernateCallback<Expense>() {

			@Override
			public Expense doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Expense ex = (Expense)session.get(Expense.class, expenseId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
				
			}
		});
		return expense;
	}

	@Override
	public void updateExpense(Expense expense) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				
				Transaction tr = session.beginTransaction();
				
//				Expense ex = (Expense)session.get(Expense.class, expense.getExpenseId());
//				ex.setItemName(expense.getItemName());
//				ex.setPrice(expense.getPrice());
//				ex.setPurchaseDate(expense.getPurchaseDate()); 
				
				session.update(expense);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});

	}

	@Override
	public List<Expense> selectAll(int userId) {

		List<Expense> list = hibernateTemplate.execute(new HibernateCallback<List<Expense>>() {

			@Override
			public List<Expense> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Expense where userId = ?");
				q.setInteger(0, userId);
				List<Expense> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}

	@Override
	public List<Expense> selectReport() {

		List<Expense> list = hibernateTemplate.execute(new HibernateCallback<List<Expense>>() {

			@Override
			public List<Expense> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Expense");
				//SQLQuery  q=session.createSQLQuery("select * from expense");
				//q.addEntity(Expense.class);
			
				List<Expense> li = q.list();
				//System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}


}
